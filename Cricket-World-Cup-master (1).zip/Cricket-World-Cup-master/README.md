# Predicting the Accuracy in ICC Men's Cricket World Cup
A Data Mining, Warehousing & Visualization Project
